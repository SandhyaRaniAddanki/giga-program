

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * Servlet implementation class Servlet1
 */
@WebServlet("/Servlet1")
public class Servlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servlet1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
				try {
					String s1,s5,s6,s7,s8;
					String s3,s2,s4;
					PrintWriter out=response.getWriter();
					response.setContentType("text/html");
					Class.forName("com. mysql.jdbc.Driver");
					String jdbcUrl = "jdbc:mysql://localhost:3306/sandhya";
			        String dbUser = "root";
			        String dbPassword = "131824";
			        Connection c = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);
					 s1=request.getParameter("a1");
					 s2=request.getParameter("a2");
				     s3=request.getParameter("a3");
					 s4=request.getParameter("a4");
					 s5=request.getParameter("a5");
					 s6=request.getParameter("a6");
					 s7=request.getParameter("a7");
					 s8=request.getParameter("a8");
					 String g="insert into table1_1(name,amount,year,duration)values(?,?,?,?)";
					 PreparedStatement ps= c.prepareStatement(g);
					 ps.setString(1,s1);
					 ps.setString(2,s2);
					 ps.setString(3,s3);
					 ps.setString(4,s4);
					 int x=ps.executeUpdate();
					 
					 String h="insert into table1_2(name,name2,year,award)values(?,?,?,?)";
					 PreparedStatement p= c.prepareStatement(h);
					 p.setString(1,s5);
					 p.setString(2,s6);
					 p.setString(3,s7);
					 p.setString(4,s8);
					 int x1=ps.executeUpdate();
					 if(x1>0 && x>0)
					 {
						 out.println("successfully uploaded");
					 }
					 else {
						 out.println("please insert your details again");
					 }
					} catch (Exception e) {
						System.out.println(e);
					    e.printStackTrace();
				}
			}

			
		}

	


