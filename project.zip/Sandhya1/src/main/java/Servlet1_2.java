

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * Servlet implementation class Servlet1
 */
@WebServlet("/Servlet1_2")
public class Servlet1_2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servlet1_2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		try {
			String s1, s3,s2,s4;
			PrintWriter out=response.getWriter();
			response.setContentType("text/html");
			Class.forName("com. mysql.cj.Driver");
			 Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/sandhya","root","sANDHYA_1117");
			 s1=request.getParameter("a1");
			 s2=request.getParameter("a2");
		     s3=request.getParameter("a3");
			 s4=request.getParameter("a4");
			 String g="select * from table1_1 where  name="+s1+"and year="+s2+";" ;
			  c.createStatement();
			 PreparedStatement p=c.prepareStatement(g);
			 ResultSet x=p.executeQuery();
			 out.println("NAME OF THE PROJECT\t\tNAME OF THE PRINCIPLE INVESTIGATOR\t\tDEPARTMENT OF PRINCIPLE INVESTIGATOR\t\tYEAR OF THE AWARd\t\tFUNDS PROVIDEd\t\tDURATION OF THE PROJECT");
			 if(x.next())
			 {
				 String a=x.getString("name1");
				 String b=x.getString("name2");
				 String c1=x.getString("dept");
				 String d=x.getString("year");
				 String d2=x.getString("funds");
				 String d1=x.getString("duration");
				 out.println(a+"\t\t"+b+"\t\t"+c1+"\t\t"+d+"\t\t"+d2+"\t\t"+d1);
			 }
			 else {
				 out.println(" no grants for "+s1+"department during the year"+s2);
			 }
			 String g1="select * from table1_2 where  name="+s3+"and year="+s4+";" ;
			 PreparedStatement p1=c.prepareStatement(g1);
			 ResultSet x1=p1.executeQuery();
			 out.println("Name of Principal Investigator\t\tDuration of project\t\t	Name of the research project\t\tYear of sanction\t\tAmount / Fund received\t\tDepartment of recipient\t\tName of funding agency ");
			 if(x1.next())
			 {
				 String a=x.getString("name1");
				 String b=x.getString("duration");
				 String c1=x.getString("name2");
				 String d=x.getString("year");
				 String d1=x.getString("amount");
				 String d11=x.getString("dept");
				 String d111=x.getString("name3");
				 out.println(a+"\t\t"+b+"\t\t"+c1+"\t\t"+d+"\t\t"+d1+"\t\t"+d11+"\t\t"+d111);
			 }
			 else {
				 out.println(" no grants for "+s3+"department during the year"+s4);
			 }
			} catch (Exception e) {
				System.out.println(e);
			    e.printStackTrace();
		}
	}

	
}
