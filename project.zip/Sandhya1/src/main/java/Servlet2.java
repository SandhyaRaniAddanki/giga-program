 import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
 import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/Servlet2")
public class Servlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException  {
		PrintWriter out=response.getWriter();
		try {
			String s1,s9,s11,s13,s2,s3,s15;
			String s4,s5,s6,s7,s8,s10,s12,s14;
			response.setContentType("text/html");
		
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/sandhya","root","sANDHYA_1117");
			if(c!=null)
				System.out.println("Connection done");
			else
				System.out.println("Connection failed");
			s1=request.getParameter("2.1");
			s2=request.getParameter("2.2");
			s3=request.getParameter("2.3");
			s4=request.getParameter("2.4");
		    s5=request.getParameter("2.5");
			s6=request.getParameter("2.6");
			s7=request.getParameter("2.7");
			s8=request.getParameter("2.8");
		    s9=request.getParameter("2.9");
			s10=request.getParameter("2.10");
			s11=request.getParameter("2.11");
			s12=request.getParameter("2.12");
			s13=request.getParameter("2.13");
			s14=request.getParameter("2.14");
			s15=request.getParameter("2.15");
			String g="insert into table2_2(project,name,dept,year,funds,duration)values(?,?,?,?,?,?)";
			String i="insert into table2_4(name,duration,name2,amount,name3,year,department)values(?,?,?,?,?,?,?)";
			String h="insert into table2_3(number1,number2)values(?,?)";
			 PreparedStatement p= c.prepareStatement(g);
			 p.setString(1,s1);
			 p.setString(2,s2);
			 p.setString(3,s3);
			 p.setString(4,s4);
			 p.setString(5,s5);
			 p.setString(6,s6);
			 int x1=p.executeUpdate();
			 if(x1>0)
			 {
				 out.println("successfully uploaded");
			 }
			 else {
				 out.println("please insert your details again");
			 }
			 PreparedStatement p1= c.prepareStatement(i);
			 p1.setString(1,s7);
			 p1.setString(2,s8);
			 int x2=p1.executeUpdate();
			 if(x2>0)
			 {
				 out.println("successfully uploaded");
			 }
			 else {
				 out.println("please insert your details again");
			 }
			 PreparedStatement p2= c.prepareStatement(h);
			 p2.setString(1,s9);
			 p2.setString(2,s10);
			 p2.setString(3,s11);
			 p2.setString(4,s12);
			 p2.setString(5,s13);
			 p2.setString(6,s14);
			 p2.setString(7,s15);
			 int x3=p2.executeUpdate();
			 if(x3>0)
			 {
				 out.println("successfully uploaded");
			 }
			 else {
				 out.println("please insert your details again");
			 }
			} catch (Exception e) {
			// TODO Auto-generated catch block
				out.println(e);
			e.printStackTrace();
		}
	}
}