

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Servlet1_1
 */
public class Servlet1_1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servlet1_1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		try {
			String s1, s3,s2,s4;
			PrintWriter out=response.getWriter();
			response.setContentType("text/html");
			Class.forName("com. mysql.cj.Driver");
			 Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/sandhya","root","sANDHYA_1117");
			 s1=request.getParameter("a1");
			 s2=request.getParameter("a2");
		     s3=request.getParameter("a3");
			 s4=request.getParameter("a4");
			 String g="select * from table1_1 where  name="+s1+"and year="+s2+";" ;
			  c.createStatement();
			 PreparedStatement p=c.prepareStatement(g);
			 ResultSet x=p.executeQuery();
			 out.println(" NAME OF THE TEACHER GETTING SEED MONEY\t\tDEPT OF THE TEACHER\t\tAMOUNT OF SEED MONEY\t\tYEAR OF RECEIVING GRANT\t\tDURATION OF THE GRANT");
			 if(x.next())
			 {
				 String a=x.getString("name");
				 String b=x.getString("dept");
				 String c1=x.getString("amount");
				 String d=x.getString("year");
				 String d1=x.getString("duration");
				 out.println(a+"\t\t"+b+"\t\t"+c1+"\t\t"+d+"\t\t"+d1);
			 }
			 else {
				 out.println(" no grants for "+s1+"department during the year"+s2);
			 }
			 String g1="select * from table1_2 where  name="+s3+"and year="+s4+";" ;
			 PreparedStatement p1=c.prepareStatement(g1);
			 ResultSet x1=p1.executeQuery();
			 out.println(" NAME OF THE TEACHER\t\tNAME OF THE AWARD\t\tDEPT OF THE TEACHER\t\tYEAR OF THE AWARD\t\tAWARDING AGENCY");
			 if(x1.next())
			 {
				 String a=x.getString("name1");
				 String b=x.getString("name2");
				 String c1=x.getString("dept");
				 String d=x.getString("year");
				 String d1=x.getString("agency");
				 out.println(a+"\t\t"+b+"\t\t"+c1+"\t\t"+d+"\t\t"+d1);
			 }
			 else {
				 out.println(" no grants for "+s3+"department during the year"+s4);
			 }
			} catch (Exception e) {
				System.out.println(e);
			    e.printStackTrace();
		}
	}

	

	}


